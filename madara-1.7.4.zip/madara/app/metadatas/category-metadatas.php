<?php

	/**
	 * Initialize the category metadatas
	 *
	 * @since Madara Alpha 1.0
	 * @package madara
	 */

	//leave blank for further customizations