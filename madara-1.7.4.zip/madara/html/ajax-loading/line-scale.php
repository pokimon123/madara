<?php
	/*
	*
	* line-scale
	*
	*/
?>
<div class="loader-inner line-scale">
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
</div>