<?php
	/*
	*
	* ball-pulse
	*
	*/
?>
<div class="loader-inner ball-pulse">
    <div></div>
    <div></div>
    <div></div>
</div>