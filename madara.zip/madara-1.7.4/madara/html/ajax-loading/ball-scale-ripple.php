<?php
	/*
	*
	* ball-scale-ripple
	*
	*/
?>
<div class="loader-inner ball-scale-ripple">
    <div></div>
</div>