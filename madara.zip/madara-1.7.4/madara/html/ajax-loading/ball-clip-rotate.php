<?php
	/*
	*
	* ball-clip-rotate
	*
	*/
?>
<div class="loader-inner ball-clip-rotate">
    <div></div>
</div>