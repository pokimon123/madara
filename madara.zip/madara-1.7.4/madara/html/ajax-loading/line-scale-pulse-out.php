<?php
	/*
	*
	* line-scale-pulse-out
	*
	*/
?>
<div class="loader-inner line-scale-pulse-out">
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
</div>