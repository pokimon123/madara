<?php
	/*
	*
	* ball-spin-fade-loader
	*
	*/
?>
<div class="loader-inner ball-spin-fade-loader">
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
</div>