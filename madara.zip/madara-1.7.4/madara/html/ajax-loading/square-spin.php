<?php
	/*
	*
	* square-spin
	*
	*/
?>
<div class="loader-inner square-spin">
    <div></div>
</div>