<?php

	/**
	 * Class Thumbnail
	 *
	 * @package madara
	 */

	namespace App\Models\Entity;

	use App\Models;

	class Thumbnail extends Models\Metadata {
		public function __construct() {

		}
	}