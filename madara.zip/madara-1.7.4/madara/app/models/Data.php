<?php

	/**
	 * Class CT_Data_M
	 *
	 * @package madara
	 */

	namespace App\Models;

	abstract class Data extends \wpdb {
		public function __construct() {

		}
	}