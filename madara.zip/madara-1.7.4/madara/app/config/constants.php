<?php

	/**
	 * Madara Constants
	 */

	//Madara Mega-Menu

	define( 'MEGAMENU_VERSION', '1.6' );
	define( 'MEGAMENU_NAV_LOCS', 'wp-mega-menu-nav-locations' );
