<?php
	/**
	 * Madara Functions and Definitions
	 *
	 * @package madara
	 */
	require( get_template_directory() . '/app/theme.php' );
